# linset

Linset Edited Version  by Mr. Spider. 

Change : 

[+] Add Index Files into Folder "scama"

[+] Remove WPA SUPPLICANT check 



